data_summary <- function(x) {
  m <- median(x)
  ymin <- m-sd(x)
  ymax <- m+sd(x)
  return(c(y=m,ymin=ymin,ymax=ymax))
}

# Differentials by stage

nPpts <- nrow(aggData)


#xb <- c("Geography","History & Politics", "People & Culture")
#yb <- c(mean(aggData$meanInitialDiffs),
       # mean(aggData$meanMiddleDiffs),
      #  mean(aggData$meanFinalDiffs))
xb <- c(rep("Geography",nPpts),rep("History & Politics",nPpts), rep("People & Culture",nPpts))
yb <- c(aggData$meanInitialDiffs, aggData$meanMiddleDiffs, aggData$meanFinalDiffs)
dataF <- data.frame("Stage" = xb, "Mean"= yb)
dataF$ID <- rep(c(1:nPpts),3)
#diffs <- ggplot(dataF) +
#  geom_bar( aes(x=Stage, y=Mean), colour="black", stat="identity", fill=differentialColour, alpha=1)

dataF$Stage <- as.factor(dataF$Stage)
diffs <- ggplot(dataF, aes(x=Stage, y=Mean)) +
  geom_violin(colour="black", fill=differentialColour, alpha=0.8, trim=FALSE) + 
  geom_path(aes(group = ID), size = 0.2, alpha = 0.4) +
  geom_point(shape=16, position=position_jitter(width = 0.04, seed = 12), colour="white") +
  stat_summary(fun.data=data_summary, colour="red")

print(diffs +
        ggtitle("Average Differentials by Information Seeking Stage") +
        labs(x = "Stage", y = "Average Differentials") +
        theme_classic()) 

res.aov2 <- anova_test(
  data = dataF, dv = Mean, wid = ID, within = Stage
)
get_anova_table(res.aov2)


# Information proportion by stage

#yb <- c(mean(aggData$initialPropOfInfo),
#        mean(aggData$middlePropOfInfo),
#        mean(aggData$finalPropOfInfo))
yb <- c(aggData$initialPropOfInfo, aggData$middlePropOfInfo, aggData$finalPropOfInfo)
dataF <- data.frame("Stage" = xb, "Mean"= yb)
dataF$ID <- rep(c(1:nPpts),3)
#inf <- ggplot(dataF) +
#  geom_bar( aes(x=Stage, y=Mean), colour="black", stat="identity", fill=infoSeekingColour, alpha=0.7)

dataF$Stage <- as.factor(dataF$Stage)
inf <- ggplot(dataF, aes(x=Stage, y=Mean)) +
  geom_violin(colour="black", fill=infoSeekingColour, alpha=0.8, trim=FALSE) + 
  geom_path(aes(group = ID), size = 0.2, alpha = 0.4) +
  geom_point(shape=16, position=position_jitter(width = 0.04, seed = 12), colour="white") +
  stat_summary(fun.data=data_summary, colour="red")



print(inf +
        ggtitle("Information Gathering by Information Seeking Stage") +
        labs(x = "Stage", y = "Proportion of Available Information Sought") +
        theme_classic()) 

res.aov2 <- anova_test(
  data = dataF, dv = Mean, wid = ID, within = Stage
)
get_anova_table(res.aov2)

# Confidence by stage

yb <- c(mean(aggData$meanInitialConfidence),
       mean(aggData$meanMiddleConfidence),
        mean(aggData$meanFinalConfidence))
#yb <- c(aggData$meanInitialConfidence, aggData$meanMiddleConfidence, aggData$meanFinalConfidence)
dataF <- data.frame("Stage" = xb, "Mean"= yb)
inf <- ggplot(dataF) +
  geom_bar( aes(x=Stage, y=Mean), colour="black", stat="identity", fill=confidenceColour, alpha=0.7)

dataF$Stage <- as.factor(dataF$Stage)
inf <- ggplot(dataF, aes(x=Stage, y=Mean)) +
  geom_violin(colour="black", fill=confidenceColour, alpha=0.8, trim=FALSE) + 
  geom_jitter(shape=16, position=position_jitter(0.04), colour="white") +
  stat_summary(fun.data=data_summary, colour="red")

print(inf +
        ggtitle("Confidence by Information Seeking Stage") +
        labs(x = "Stage", y = "Mean Confidence") +
        theme_classic()) 

dataF$ID <- rep(c(1:nPpts),3)
res.aov2 <- anova_test(
  data = dataF, dv = Mean, wid = ID, within = Stage
)
get_anova_table(res.aov2)

# Accuracy by stage

#yb <- c(mean(aggData$meanInitialAccuracy),
#        mean(aggData$meanMiddleAccuracy),
#        mean(aggData$meanFinalAccuracy))
yb <- c(aggData$meanInitialAccuracy, aggData$meanMiddleAccuracy, aggData$meanFinalAccuracy)
dataF <- data.frame("Stage" = xb, "Mean"= yb)
#inf <- ggplot(dataF) +
#  geom_bar( aes(x=Stage, y=Mean), colour="black", stat="identity", fill=accuracyColour, alpha=0.7)

dataF$Stage <- as.factor(dataF$Stage)
inf <- ggplot(dataF, aes(x=Stage, y=Mean)) +
  geom_violin(colour="black", fill=accuracyColour, alpha=0.8, trim=FALSE) + 
  geom_jitter(shape=16, position=position_jitter(0.04), colour="white") +
  stat_summary(fun.data=data_summary, colour="red")

print(inf +
        ggtitle("Accuracy by Information Seeking Stage") +
        labs(x = "Stage", y = "Mean Accuracy") +
        theme_classic()) 

dataF$ID <- rep(c(1:nPpts),3)
res.aov2 <- anova_test(
  data = dataF, dv = Mean, wid = ID, within = Stage
)
get_anova_table(res.aov2)

# Likelihood of correct country by stage (include zeros)

#yb <- c(mean(aggData$averageLikelihoodOfCorrectCountryInitial,na.rm=TRUE),
#        mean(aggData$averageLikelihoodOfCorrectCountryMiddle,na.rm=TRUE ),
#        mean(aggData$averageLikelihoodOfCorrectCountryFinal, na.rm=TRUE))
yb <- c(aggData$averageLikelihoodOfCorrectCountryInitial, aggData$averageLikelihoodOfCorrectCountryMiddle, aggData$averageLikelihoodOfCorrectCountryFinal)
dataF <- data.frame("Stage" = xb, "Mean"= yb)
dataF$ID <- rep(c(1:nPpts),3)
#inf <- ggplot(dataF) +
#  geom_bar( aes(x=Stage, y=Mean), colour="black", stat="identity", fill=likelihoodColour, alpha=0.7)

dataF$Stage <- as.factor(dataF$Stage)
inf <- ggplot(dataF, aes(x=Stage, y=Mean)) +
  geom_violin(colour="black", fill=likelihoodColour, alpha=0.8, trim=FALSE) + 
  geom_path(aes(group = ID), size = 0.2, alpha = 0.4) +
  geom_point(shape=16, position=position_jitter(width = 0.04, seed = 12), colour="white") +
  stat_summary(fun.data=data_summary, colour="red")

print(inf +
        ggtitle("Likelihood of Correct Country by Information Seeking Stage") +
        labs(x = "Stage", y = "Likelihood Rating") +
        theme_classic()) 

res.aov2 <- anova_test(
  data = dataF, dv = Mean, wid = ID, within = Stage
)
get_anova_table(res.aov2)


# Likelihood of incorrect countries by stage (include zeros)


yb <- c(aggData$incorrectLikelihoodInitial, aggData$incorrectLikelihoodMiddle, aggData$incorrectLikelihoodFinal)
dataF <- data.frame("Stage" = xb, "Mean"= yb)
#inf <- ggplot(dataF) +
#  geom_bar( aes(x=Stage, y=Mean), colour="black", stat="identity", fill=likelihoodColour, alpha=0.7)

dataF$Stage <- as.factor(dataF$Stage)
inf <- ggplot(dataF, aes(x=Stage, y=Mean)) +
  geom_violin(colour="black", fill=likelihoodColour, alpha=0.8, trim=FALSE) + 
  geom_jitter(shape=16, position=position_jitter(0.04), colour="white") +
  stat_summary(fun.data=data_summary, colour="red")

print(inf +
        ggtitle("Likelihood of Incorrect Countries by Information Seeking Stage") +
        labs(x = "Stage", y = "Likelihood Rating") +
        theme_classic()) 

dataF$ID <- rep(c(1:nPpts),3)
res.aov2 <- anova_test(
  data = dataF, dv = Mean, wid = ID, within = Stage
)
get_anova_table(res.aov2)
