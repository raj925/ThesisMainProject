mds <- infoSeekingFullMatrix[,1:29] %>%
  dist() %>%          
  cmdscale() %>%
  as_tibble()

distances <- infoSeekingFullMatrix[,1:29] %>% dist() %>% as.matrix()

infoSeekingFullMatrix$v1 <- mds$V1
infoSeekingFullMatrix$v2 <- mds$V2

cases <- countriesShort

######################################
# Distance heat plot by case

distanceMatrix <- data.frame(matrix(ncol = 6, nrow = 6))
for (x in 1:length(cases))
{
  case <- cases[x]
  for (y in 1:length(cases))
  {
    if (y == x)
    {
      distanceMatrix[x,y] <- 0
      colnames(distanceMatrix)[y] <- paste(y, ". ", case)
    }
    else
    {
      comparisonCase <- cases[y]
      compareColumns <- distances[grep(comparisonCase, rownames(distances)), ]
      compareColumns <- compareColumns[,grep(case, colnames(compareColumns)) ]
      meanDist <- mean(compareColumns)
      distanceMatrix[x,y] <- meanDist-3
      colnames(distanceMatrix)[y] <- paste(y, ". ", comparisonCase)
    }
  }
  rownames(distanceMatrix)[x] <- paste(x, ". ", case)
}

dt2 <- distanceMatrix %>%
  rownames_to_column() %>%
  gather(colname, value, -rowname)
print(ggplot(dt2, aes(x = colname, y = rowname, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "#075AFF",
                       mid = "#FFFFCC",
                       high = "#FF0000"))

##########

# Look at variance in distances 

# By country

caseVars <- c()
infoSeeks <- c()
for (x in 1:length(cases))
{
  compareColumns <- distances[grep(cases[x], rownames(distances)), ]
  compareColumns <- compareColumns[,grep(cases[x], colnames(compareColumns)) ]
  caseVars[x] <- (sd(compareColumns))^2
  idx <- match(cases[x],cases)
  infoSeeks[x] <- mean(countryDf[countryDf$country==countriesLong[idx],]$caseInformationProportion,na.rm=TRUE)
}

dataCaseVar <- data.frame("Case" = cases, "Variance"= caseVars, "InfoSeeking" = infoSeeks)
diffs <- ggplot(dataCaseVar) +
  geom_bar( aes(x=Case, y=Variance), colour="black", stat="identity", fill=accuracyColour, alpha=0.8)

print(diffs +
        ggtitle("Variance in Information Seeking by Country") +
        labs(x = "Case", y = "Variance in MDS Distances") +
        theme_classic()) 

infoSeeking <- ggplot(dataCaseVar) +
  geom_bar( aes(x=Case, y=InfoSeeking), colour="black", stat="identity", fill=infoSeekingColour, alpha=0.8)

print(infoSeeking +
        ggtitle("Proportion of Information Seeking by Country") +
        labs(x = "Case", y = "Variance in MDS Distances") +
        theme_classic()) 

# By accuracy

accVars <- c()
accInfoProps <- c()
accDiffs <- c()
for (x in 1:length(accs))
{
  compareColumns <- distances[grep(accs[x], rownames(distances)), ]
  compareColumns <- compareColumns[,grep(accs[x], colnames(compareColumns)) ]
  accVars[x] <- (summary(boot(compareColumns, varBoot, R=500)))$bootMed
  accInfoProps[x] <- mean(aggData[accs[x]==aggData$geoKnowledgeGroup,]$proportionOfInfo,na.rm=TRUE)
  accDiffs[x] <- mean(aggData[accs[x]==aggData$geoKnowledgeGroup,]$meanFinalDiffs,na.rm=TRUE)
}

dataF <- data.frame("Accuracy" = accs, "Variance"= accVars, "Differentials" = accDiffs,
                    "InformationSeeking"= accInfoProps, "correctDiagnosisLikelihood" = accVars)


diffs <- ggplot(dataF) +
  geom_bar( aes(x=Accuracy, y=Variance), colour="black", stat="identity", fill=accuracyColour, alpha=0.8)

print(diffs +
        ggtitle("Variance in Information Seeking by Participant Knowledge") +
        labs(x = "Participant Geographic Knowledge", y = "Variance in MDS Distances") +
        theme_classic()) 

diffs <- ggplot(dataF) +
  geom_bar( aes(x=Accuracy, y=InformationSeeking), colour="black", stat="identity", fill=infoSeekingColour, alpha=0.8)

print(diffs +
        ggtitle("Total Information Seeking by Participant Accuracy") +
        labs(x = "Participant Accuracy", y = "Total Information Seeking") +
        theme_classic()) 

diffs <- ggplot(dataF) +
  geom_bar( aes(x=Accuracy, y=Differentials), colour="black", stat="identity", fill=differentialColour, alpha=0.8)

print(diffs +
        ggtitle("Average Differentials by Participant Accuracy") +
        labs(x = "Participant Accuracy", y = "Number of Final Differentials") +
        theme_classic()) 



##########

# Distance heat plot by participant accuracy

distanceMatrix <- data.frame(matrix(ncol = 4, nrow = 4))
for (x in 1:length(accs))
{
  acc <- accs[x]
  for (y in 1:length(accs))
  {
    if (y == x)
    {
      distanceMatrix[x,y] <- 0
      colnames(distanceMatrix)[y] <- paste(y, ". ", acc)
    }
    else
    {
      comparisonAcc <- accs[y]
      compareColumns <- distances[grep(comparisonAcc, rownames(distances)), ]
      compareColumns <- compareColumns[,grep(acc, colnames(compareColumns)) ]
      meanDist <- mean(compareColumns)-3
      distanceMatrix[x,y] <- meanDist
      colnames(distanceMatrix)[y] <- paste(y, ". ", comparisonAcc)
    }
  }
  rownames(distanceMatrix)[x] <- paste(x, ". ", acc)
}

dt2 <- distanceMatrix %>%
  rownames_to_column() %>%
  gather(colname, value, -rowname)
print(ggplot(dt2, aes(x = colname, y = rowname, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "#075AFF",
                       mid = "#FFFFCC",
                       high = "#FF0000"))

##########

# Distance heat plot by participant accuracy AND case

accCases <- c()
for (n in 1:length(accs))
{
  for (m in 1:length(cases))
  {
    accCases[m+(length(cases)*(n-1))] <- paste(accs[n], "-", cases[m], sep="")
  }
}
distanceMatrix <- data.frame(matrix(ncol = 24, nrow = 24))
for (x in 1:length(accCases))
{
  acc <- accCases[x]
  #accSplit <- str_split(acc,"/")[[1]][2]
  for (y in 1:length(accCases))
  {
    if (y == x)
    {
      distanceMatrix[x,y] <- 0
      colnames(distanceMatrix)[y] <- acc
    }
    else
    {
      comparisonAcc <- accCases[y]
      #comparisonAccSplit <- str_split(comparisonAcc,"/")[[1]][2]
      currentAcc <- str_split(acc,"-")[[1]][1]
      nextAcc <- str_split(comparisonAcc,"-")[[1]][1]
      currentCase <- str_split(acc,"-")[[1]][2]
      nextCase <- str_split(comparisonAcc,"-")[[1]][2]
      compareColumns <- distances[grep(currentAcc, rownames(distances)), ]
      compareColumns <- compareColumns[grep(currentCase, rownames(compareColumns)), ]
      compareColumns <- compareColumns[,grep(nextAcc, colnames(compareColumns)) ]
      compareColumns <- compareColumns[,grep(nextCase, colnames(compareColumns)) ]
      meanDist <- mean(compareColumns)^2
      distanceMatrix[x,y] <- meanDist
      colnames(distanceMatrix)[y] <- comparisonAcc
    }
  }
  rownames(distanceMatrix)[x] <- acc
}

dt2 <- distanceMatrix %>%
  rownames_to_column() %>%
  gather(colname, value, -rowname)
print(ggplot(dt2, aes(x = colname, y = rowname, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "#075AFF",
                       mid = "#FFFFCC",
                       high = "#FF0000")) +
  theme(
    axis.text.x = element_text(size = 7))


##########

meanCoordinatesCaseMONv1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="MON",]$v1)
meanCoordinatesCaseMONv2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="MON",]$v2)

meanCoordinatesCaseSWIv1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="SWI",]$v1)
meanCoordinatesCaseSWIv2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="SWI",]$v2)

meanCoordinatesCaseKORv1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="KOR",]$v1)
meanCoordinatesCaseKORv2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="KOR",]$v2)

meanCoordinatesCaseCOLv1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="COL",]$v1)
meanCoordinatesCaseCOLv2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="COL",]$v2)

meanCoordinatesCaseGREv1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="GRE",]$v1)
meanCoordinatesCaseGREv2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="GRE",]$v2)

meanCoordinatesCaseBOTv1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="BOT",]$v1)
meanCoordinatesCaseBOTv2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$Country=="BOT",]$v2)

xCoordinates <- c(meanCoordinatesCaseMONv1, meanCoordinatesCaseSWIv1, meanCoordinatesCaseKORv1,
                  meanCoordinatesCaseCOLv1, meanCoordinatesCaseGREv1, meanCoordinatesCaseBOTv1)
yCoordinates <- c(meanCoordinatesCaseMONv2, meanCoordinatesCaseSWIv2, meanCoordinatesCaseKORv2,
                  meanCoordinatesCaseCOLv2, meanCoordinatesCaseGREv2, meanCoordinatesCaseBOTv2)
label <- c("easy", "easy", "easy", "hard", "hard", "hard")
plotDf <- data.frame(xCoordinates, yCoordinates,label)
labels <- countriesShort
print(ggplot(plotDf, aes(x=xCoordinates, y=yCoordinates)) +
  geom_point(aes(colour=factor(label), size=0.02)) + # Show dots
  geom_text(
    label=labels, 
    nudge_x = 0.01, nudge_y = 0.01, 
    check_overlap = T
  ))

##############


meanCoordinatesAccGroup1v1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$ParticipantAccuracy==0.3,]$v1)
meanCoordinatesAccGroup1v2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$ParticipantAccuracy==0.3,]$v2)

meanCoordinatesAccGroup2v1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$ParticipantAccuracy==0.5,]$v1)
meanCoordinatesAccGroup2v2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$ParticipantAccuracy==0.5,]$v2)

meanCoordinatesAccGroup3v1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$ParticipantAccuracy==0.7,]$v1)
meanCoordinatesAccGroup3v2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$ParticipantAccuracy==0.7,]$v2)

meanCoordinatesAccGroup4v1 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$ParticipantAccuracy==0.8,]$v1)
meanCoordinatesAccGroup4v2 <- mean(infoSeekingFullMatrix[infoSeekingFullMatrix$ParticipantAccuracy==0.8,]$v2)

xCoordinates <- c(meanCoordinatesAccGroup1v1, meanCoordinatesAccGroup2v1, meanCoordinatesAccGroup3v1,
                  meanCoordinatesAccGroup4v1)
yCoordinates <- c(meanCoordinatesAccGroup1v2, meanCoordinatesAccGroup2v2, meanCoordinatesAccGroup3v2,
                  meanCoordinatesAccGroup4v2)
plotDf <- data.frame(xCoordinates, yCoordinates)
labels <- c("AccGroup1", "AccGroup2", "AccGroup3", "AccGroup4")
print(ggplot(plotDf, aes(x=xCoordinates, y=yCoordinates)) +
  geom_point() + # Show dots
  geom_text(
    label=labels, 
    nudge_x = 0.01, nudge_y = 0.01, 
    check_overlap = T
  ))

##############

if (clusterType == "pam")
{
  # Clustering by PAM rather than k means
  pamResult <-pam(mds, k = numOfClusters)
  mds <- mds %>%
    mutate(groups = pamResult$clustering)
  infoSeekingFullMatrix$cluster <- pamResult$clustering
  mds$groups <- as.factor(mds$groups)
}
if (clusterType == "kmeans")
{
  # K-means clustering
  clust <- kmeans(mds, numOfClusters, iter.max=1000,nstart = 10)$cluster %>%
    as.factor()
  mds <- mds %>%
    mutate(groups = clust)
  infoSeekingFullMatrix$cluster <- clust
}
# Plot and color by groups
print(ggscatter(mds, x = "V1", y = "V2", 
          label = rownames(infoSeekingFullMatrix),
          color = "groups",
          palette = "jco",
          size = 1, 
          ellipse = TRUE,
          ellipse.type = "convex",
          repel = TRUE))

if (numOfClusters == 2)
{
  clusterLabels <- c()
  accGroupLabels <- c()
  values <- c()
  for (i in 1:numOfClusters)
  {
    group <- infoSeekingFullMatrix[infoSeekingFullMatrix$cluster==i,]
    size <- nrow(group)
    #initialAccGroup1 <- nrow(group[group$InitialCorrect==0,])/size
    #initialAccGroup2 <- nrow(group[group$InitialCorrect==1,])/size
    resGroup1 <- nrow(group[group$ResolutionGroup==1,])/size
    resGroup2 <- nrow(group[group$ResolutionGroup==2,])/size
    
    clusterLab <- paste("Cluster", i, sep="")
    clusterLabels <- c(clusterLabels, rep(clusterLab , 2) )
    accGroupLabels <- c(accGroupLabels, c("NegativeResolutionGroup", "PositiveResolutionGroup"))
    values <- c(values, c(resGroup1, resGroup2))
  }
  clusterAccDf <- data.frame(clusterLabels, accGroupLabels, values)
  
  print(ggplot(clusterAccDf, aes(fill=accGroupLabels, y=values, x=clusterLabels)) +
    geom_bar(position="stack", stat="identity"))
}
## Look at clustering and whether it corresponds with ppt accuracy
if (numOfClusters == 3)
{
  clusterLabels <- c()
  accGroupLabels <- c()
  values <- c()
  for (i in 1:numOfClusters)
  {
    group <- infoSeekingFullMatrix[infoSeekingFullMatrix$cluster==i,]
    size <- nrow(group)
    diffGroup1 <- nrow(group[group$CaseDifficultyGroup==1,])/size
    diffGroup2 <- nrow(group[group$CaseDifficultyGroup==2,])/size
    diffGroup3 <- nrow(group[group$CaseDifficultyGroup==3,])/size
    
    clusterLab <- paste("Cluster", i, sep="")
    clusterLabels <- c(clusterLabels, rep(clusterLab , 3) )
    accGroupLabels <- c(accGroupLabels, c("1. easyDiffGroup", "2. medDiffGroup", "3. hardDiffGroup"))
    values <- c(values, c(diffGroup1, diffGroup2, diffGroup3))
  }
  clusterAccDf <- data.frame(clusterLabels, accGroupLabels, values)
  
  print(ggplot(clusterAccDf, aes(fill=accGroupLabels, y=values, x=clusterLabels)) + 
    geom_bar(position="stack", stat="identity"))
}
## Look at clustering and whether it corresponds with ppt accuracy
if (numOfClusters == 4)
{
  clusterLabels <- c()
  accGroupLabels <- c()
  values <- c()
  for (i in 1:numOfClusters)
  {
    group <- infoSeekingFullMatrix[infoSeekingFullMatrix$cluster==i,]
    size <- nrow(group)
    accGroup1 <- nrow(group[group$GeoKnowledgeGroup==1,])/size
    accGroup2 <- nrow(group[group$GeoKnowledgeGroup==2,])/size
    accGroup3 <- nrow(group[group$GeoKnowledgeGroup==3,])/size
    accGroup4 <- nrow(group[group$GeoKnowledgeGroup==4,])/size
    
    clusterLab <- paste("Cluster", i, sep="")
    clusterLabels <- c(clusterLabels, rep(clusterLab , 4) )
    accGroupLabels <- c(accGroupLabels, c("geoKnowledgeGroup1", "geoKnowledgeGroup2", "geoKnowledgeGroup3", "geoKnowledgeGroup4"))
    values <- c(values, c(accGroup1, accGroup2, accGroup3, accGroup4))
  }
  clusterAccDf <- data.frame(clusterLabels, accGroupLabels, values)
  
  print(ggplot(clusterAccDf, aes(fill=accGroupLabels, y=values, x=clusterLabels)) + 
    geom_bar(position="stack", stat="identity"))
}
## Look at clustering and whether it corresponds with case
if (numOfClusters == 6)
{
  clusterLabels <- c()
  caseGroupLabels <- c()
  values <- c()
  for (i in 1:numOfClusters)
  {
    group <- infoSeekingFullMatrix[infoSeekingFullMatrix$cluster==i,]
    size <- nrow(group)
    caseGroup1 <- nrow(group[group$Country=="MON",])/size
    caseGroup2 <- nrow(group[group$Country=="SWI",])/size
    caseGroup3 <- nrow(group[group$Country=="KOR",])/size
    caseGroup4 <- nrow(group[group$Country=="COL",])/size
    caseGroup5 <- nrow(group[group$Country=="GRE",])/size
    caseGroup6 <- nrow(group[group$Country=="BOT",])/size
    
    clusterLab <- paste("Cluster", i, sep="")
    clusterLabels <- c(clusterLabels, rep(clusterLab , 6) )
    caseGroupLabels <- c(caseGroupLabels, c("countryGroupMON", "countryGroupSWI", "countryGroupKOR", "countryGroupCOL", "countryGroupGRE", "countryGroupBOT"))
    values <- c(values, c(caseGroup1, caseGroup2, caseGroup3, caseGroup4, caseGroup5, caseGroup6))
  }
  clusterAccDf <- data.frame(clusterLabels, caseGroupLabels, values)
  
  print(ggplot(clusterAccDf, aes(fill=caseGroupLabels, y=values, x=clusterLabels)) + 
    geom_bar(position="stack", stat="identity"))
}


##############

#################################
infoseeking.pca <- prcomp(distances, center = TRUE,scale. = TRUE)

summary(infoseeking.pca)

infoseeking.country <- infoSeekingFullMatrix$Country
infoseeking.accGroup <- as.factor(infoSeekingFullMatrix$LikelihoodCorrectGroup)

ggbiplot(infoseeking.pca,ellipse=TRUE,choices=c(1,2), obs.scale = 1, var.scale = 1, var.axes=FALSE, groups=infoseeking.accGroup) +
  ggtitle("PCA of Info Seeking Matrix")+
  theme_minimal()+
  theme(legend.position = "bottom")

###################


# Look at variance in information seeking varies as a function
# of case difficulty and ability 

pptIds <- c()
pptAcc <- c()
distanceVarsEasyCases <- c()
#distanceVarsMedCases <- c()
distanceVarsHardCases <- c()
infoSeekingEasy <- c()
#infoSeekingMed <- c()
infoSeekingHard <- c()
confidenceHard <- c()
confidenceEasy <- c()
geoKnowledge <- c()

for (n in 1:nrow(aggData))
{
  ppt <- paste("p", n, sep="")
  pptIds[n] <- ppt
  #pptAcc[n] <- round(aggData$meanFinalAccuracy[n],1)
  pptAcc[n] <- round(aggData$averageLikelihoodOfCorrectCountryFinal[n],1)

  
  compareColumns <- distances[grep(ppt, rownames(distances)), ]
  compareColumns <- compareColumns[,grep(ppt, colnames(compareColumns)) ]
  
  compareColumns <- compareColumns[grep(paste(easyCountryGroup, collapse="|"), rownames(compareColumns)), ]
  compareColumns <- compareColumns[,grep(paste(easyCountryGroup, collapse="|"), colnames(compareColumns)) ]
  distanceVarsEasyCases[n] <- (sd(compareColumns))^2
  
  
  #compareColumns <- distances[grep(ppt, rownames(distances)), ]
  #compareColumns <- compareColumns[,grep(ppt, colnames(compareColumns)) ]
  
  #compareColumns <- compareColumns[grep(paste(medCountryGroup, collapse="|"), rownames(compareColumns)), ]
  #compareColumns <- compareColumns[,grep(paste(medCountryGroup, collapse="|"), colnames(compareColumns)) ]
  #distanceVarsMedCases[n] <- (sd(compareColumns))^2
  
  compareColumns <- distances[grep(ppt, rownames(distances)), ]
  compareColumns <- compareColumns[,grep(ppt, colnames(compareColumns)) ]
  
  compareColumns <- compareColumns[grep(paste(hardCountryGroup, collapse="|"), rownames(compareColumns)), ]
  compareColumns <- compareColumns[,grep(paste(hardCountryGroup, collapse="|"), colnames(compareColumns)) ]
  distanceVarsHardCases[n] <- (sd(compareColumns))^2
  
  geoKnowledge[n] <- aggData$geoScore[n]
  
  infoSeekingEasy[n] <- mean(countryDf[countryDf$id==aggData$participantID[n]&countryDf$countryCode %in% easyCountryGroup,]$caseInformationProportion)
  #infoSeekingMed[n] <- mean(countryDf[countryDf$id==aggData$participantID[n]&countryDf$countryCode %in% medCountryGroup,]$caseInformationProportion)
  infoSeekingHard[n] <- mean(countryDf[countryDf$id==aggData$participantID[n]&countryDf$countryCode %in% hardCountryGroup,]$caseInformationProportion)
  
  confidenceEasy[n] <- mean(abs(countryDf[countryDf$id==aggData$participantID[n]&countryDf$countryCode %in% easyCountryGroup,]$finalConfidence))
  confidenceHard[n] <- mean(abs(countryDf[countryDf$id==aggData$participantID[n]&countryDf$countryCode %in% hardCountryGroup,]$finalConfidence))
  
}
distVarByDiff <- data.frame(pptIds, pptAcc,distanceVarsEasyCases,distanceVarsHardCases,geoKnowledge,infoSeekingEasy,infoSeekingHard,confidenceEasy,confidenceHard)
colnames(distVarByDiff) <- c("ParticipantID","ParticipantAccuracy", "EasyDistanceVariance","HardDistanceVariance","GeographicKnowledge","EasyInfoSeeking", "HardInfoSeeking","EasyConfidenceChange","HardConfidenceChange")

medAcc <- median(aggData$geoScore)

easyLow <- distVarByDiff[distVarByDiff$GeographicKnowledge<=medAcc,]$EasyDistanceVariance
easyHigh <- distVarByDiff[distVarByDiff$GeographicKnowledge>medAcc,]$EasyDistanceVariance
#medLow <- distVarByDiff[distVarByDiff$GeographicKnowledge<=medAcc,]$MedDistanceVariance
#medHigh <- distVarByDiff[distVarByDiff$GeographicKnowledge>medAcc,]$MedDistanceVariance
hardLow <- distVarByDiff[distVarByDiff$GeographicKnowledge<=medAcc,]$HardDistanceVariance
hardHigh <- distVarByDiff[distVarByDiff$GeographicKnowledge>medAcc,]$HardDistanceVariance

anovaDf <- c(easyLow, easyHigh, hardLow, hardHigh)
anovaDf <- as.data.frame(anovaDf)
anovaDf <- cbind(anovaDf,c(rep("easy",nrow(aggData)),c(rep("hard",nrow(aggData)))))
anovaDf <- cbind(anovaDf,c(rep("low",length(easyLow)),rep("high",length(easyHigh)),rep("low",length(hardLow)),rep("high",length(hardHigh))))
anovaDf <- cbind(anovaDf,c(rep(distVarByDiff$ParticipantID,2)))
names(anovaDf)[1] <- "DistanceVariance"
names(anovaDf)[2] <- "CaseDifficulty"
names(anovaDf)[3] <- "GeographicKnowledge"
names(anovaDf)[4] <- "ID"


p <- ggboxplot(anovaDf, x = "CaseDifficulty", y = "DistanceVariance", color = "GeographicKnowledge",
               palette = c("#00AFBB", "#E7B800")) +
  scale_x_discrete(limit = c("easy","hard")) + ggtitle("MDS Distance Variance Across Geographic Knowledge and Difficulty")

plot(p)

res.aov2 <- anova_test(
  data = anovaDf, dv = DistanceVariance, wid = ID, between = GeographicKnowledge,
  within = CaseDifficulty
)
get_anova_table(res.aov2)


#####################


easyLow <- distVarByDiff[distVarByDiff$GeographicKnowledge<=medAcc,]$EasyInfoSeeking
easyHigh <- distVarByDiff[distVarByDiff$GeographicKnowledge>medAcc,]$EasyInfoSeeking
#medLow <- distVarByDiff[distVarByDiff$GeographicKnowledge<=medAcc,]$MedInfoSeeking
#medHigh <- distVarByDiff[distVarByDiff$GeographicKnowledge>medAcc,]$MedInfoSeeking
hardLow <- distVarByDiff[distVarByDiff$GeographicKnowledge<=medAcc,]$HardInfoSeeking
hardHigh <- distVarByDiff[distVarByDiff$GeographicKnowledge>medAcc,]$HardInfoSeeking

anovaDf <- c(easyLow, easyHigh, hardLow, hardHigh)
anovaDf <- as.data.frame(anovaDf)
anovaDf <- cbind(anovaDf,c(rep("easy",nrow(aggData)),c(rep("hard",nrow(aggData)))))
anovaDf <- cbind(anovaDf,c(rep("low",length(easyLow)),rep("high",length(easyHigh)),rep("low",length(hardLow)),rep("high",length(hardHigh))))
anovaDf <- cbind(anovaDf,c(rep(distVarByDiff$ParticipantID,2)))
names(anovaDf)[1] <- "InfoSeeking"
names(anovaDf)[2] <- "CaseDifficulty"
names(anovaDf)[3] <- "GeographicKnowledge"
names(anovaDf)[4] <- "ID"


p <- ggboxplot(anovaDf, x = "CaseDifficulty", y = "InfoSeeking", color = "GeographicKnowledge",
               palette = c("#00AFBB", "#E7B800")) +
  scale_x_discrete(limit = c("easy","hard")) + ggtitle("Information Seeking Proportion Across Geographic Knowledge and Difficulty")

plot(p)

res.aov2 <- anova_test(
  data = anovaDf, dv = InfoSeeking, wid = ID, between = GeographicKnowledge,
  within = CaseDifficulty
)
get_anova_table(res.aov2)



#####################


easyLow <- distVarByDiff[distVarByDiff$GeographicKnowledge<=medAcc,]$EasyConfidenceChange
easyHigh <- distVarByDiff[distVarByDiff$GeographicKnowledge>medAcc,]$EasyConfidenceChange
hardLow <- distVarByDiff[distVarByDiff$GeographicKnowledge<=medAcc,]$HardConfidenceChange
hardHigh <- distVarByDiff[distVarByDiff$GeographicKnowledge>medAcc,]$HardConfidenceChange

anovaDf <- c(easyLow, easyHigh, hardLow, hardHigh)
anovaDf <- as.data.frame(anovaDf)
anovaDf <- cbind(anovaDf,c(rep("easy",nrow(aggData)),c(rep("hard",nrow(aggData)))))
anovaDf <- cbind(anovaDf,c(rep("low",length(easyLow)),rep("high",length(easyHigh)),rep("low",length(hardLow)),rep("high",length(hardHigh))))
anovaDf <- cbind(anovaDf,c(rep(distVarByDiff$ParticipantID,2)))
names(anovaDf)[1] <- "ConfidenceChange"
names(anovaDf)[2] <- "CaseDifficulty"
names(anovaDf)[3] <- "GeographicKnowledge"
names(anovaDf)[4] <- "ID"


p <- ggboxplot(anovaDf, x = "CaseDifficulty", y = "ConfidenceChange", color = "GeographicKnowledge",
               palette = c("#00AFBB", "#E7B800")) +
  scale_x_discrete(limit = c("easy","hard")) + ggtitle("Absolute Confidence Change Across Geographic Knowledge and Difficulty")

plot(p)

res.aov2 <- anova_test(
  data = anovaDf, dv = ConfidenceChange, wid = ID, between = GeographicKnowledge,
  within = CaseDifficulty
)
get_anova_table(res.aov2)


######################################
# Bar chart that breaks down variance by case and accuracy

toMatchLow <- c("geoKnowledgeGroup1", "geoKnowledgeGroup2")
toMatchHigh <- c("geoKnowledgeGroup3", "geoKnowledgeGroup4")

compareColumnsLow <- distances[grep(paste(toMatchLow,collapse="|"), rownames(distances)), ]
compareColumnsLow <- compareColumnsLow[,grep(paste(toMatchLow,collapse="|"), colnames(compareColumnsLow)) ]
varsArr <- c()
num <- 1
for (cond in countriesShort)
{
  compareColumns <- compareColumnsLow[grep(cond, rownames(compareColumnsLow)), ]
  compareColumns <- compareColumns[,grep(cond, colnames(compareColumns)) ]
  varsArr[num] <- (sd(compareColumns))^2
  num <- num + 1
}

compareColumnsHigh <- distances[grep(paste(toMatchHigh,collapse="|"), rownames(distances)), ]
compareColumnsHigh <- compareColumnsHigh[,grep(paste(toMatchHigh,collapse="|"), colnames(compareColumnsHigh)) ]
for (cond in countriesShort)
{
  compareColumns <- compareColumnsHigh[grep(cond, rownames(compareColumnsHigh)), ]
  compareColumns <- compareColumns[,grep(cond, colnames(compareColumns)) ]
  varsArr[num] <- (sd(compareColumns))^2
  num <- num + 1
}
dataB <- data.frame(
  country=rep(c("MON", "SWI", "KOR", "COL", "GRE", "BOT") , 2),
  knowledgeGroup=c(rep("low", 6),rep("high", 6)),
  variance=varsArr
)

varsPlot <- ggplot(dataB,aes(x=country, y=variance, fill=knowledgeGroup)) +
  geom_bar(stat="identity", position="dodge", alpha=0.8)

print(varsPlot +
        scale_x_discrete(limits=countriesShort) +
        ggtitle("Variance in Information Seeking by Participant Knowledge and Country") +
        labs(x = "Country (ordered by accuracy in descending order)", y = "Variance in MDS Distances") +
        theme_classic()) 



################################
