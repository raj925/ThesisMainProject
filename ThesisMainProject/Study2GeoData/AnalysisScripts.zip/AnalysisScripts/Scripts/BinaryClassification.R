requiredPackages <- c("rpart", "caret", "tidyverse", "data.table", "verification", "glmnet",
                      "GGally", "corrplot", "verification", "ROCR", "maptree",
                      "glmnet", "gridExtra", "randomForest", "mgcv", "nnet", "pROC", "pls",
                      "gbm", "e1071", "xgboost", "DT", "NeuralNetTools", "rpart.plot", "ROCR")
new.packages <- requiredPackages[!(requiredPackages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
lapply(requiredPackages, require, character.only = TRUE)

#####################
### Binary classification of ability

# 18 and 28 are NEVER requested

# Set up data
set.seed(222)
classifierData <- infoSeekingFullMatrix[,c(1:17,19:27,29, 38)]
classifierData$GeoKnowledgeGroup <- as.integer(as.logical(classifierData$GeoKnowledgeGroup>2))
classifierData$GeoKnowledgeGroup <- as.factor(classifierData$GeoKnowledgeGroup)
colnames(classifierData) <- c("T1","T2",  "T3",  "T4",  "T5",  "T6",  "T7",  "T8",  "T9", "T10", "T11", "T12", "T13", "T14", "T15", "T16", "T17", "T19", "T20", "T21", "T22", "T23", "T24", "T25", "T26", "T27", "T29", "GeoKnowledgeGroup")

thresh<-seq(0,1,0.001)

iterations <- 100
aucTables <- data.frame(matrix(nrow = 0, ncol = 6))
for (i in 1:iterations)
{
  set.seed(i*100)
  # Split into training and test data
  indexes<-sample(nrow(classifierData),0.8*nrow(classifierData),replace = F)
  train<-classifierData[indexes,]
  test<-classifierData[-indexes,]
  #train <- classifierData
  #test <- classifierData
  
  #####################
  
  
  # We use multiple methods 
  ###### Here is a generalised logistic regression #####
  full.log.probit<-glm(data = train,GeoKnowledgeGroup~.,family = binomial(link=probit))
  summary(full.log.probit)
  full.log.probit.prediction<-predict(full.log.probit,type = "response")
  roc.plot(x = train$GeoKnowledgeGroup == "1", pred = full.log.probit.prediction,thresholds = thresh)$roc.vol
  
  ###### Classification Tree ######
  full.rpart<-rpart(data = train,GeoKnowledgeGroup~.,method = 'class',parms=list(prior = c(.65,.35), split="information"))
  rpart.plot(full.rpart)
  plotcp(full.rpart)
  printcp(full.rpart)
  rpart.prediction<-predict(full.rpart,type = 'prob')
  roc.plot(x = train$GeoKnowledgeGroup == "1", pred = rpart.prediction[,2],thresholds = thresh)$roc.vol
  
  ###### Linear Discriminant Analysis #######
  
  model.lda<-lda(data=train,GeoKnowledgeGroup~.)
  lda.predicted<-predict(model.lda)$posterior[,2]
  roc.plot(x=train$GeoKnowledgeGroup=="1",pred=lda.predicted,thresholds = thresh)$roc.vol
  
  ##### Random Forest #####
  full.randomForest<-randomForest(data=train,GeoKnowledgeGroup~.,ntree=1000)
  plot(full.randomForest)
  rf.predicted<-predict(full.randomForest,type = 'prob')
  roc.plot(x = train$GeoKnowledgeGroup == "1", pred = rf.predicted[,2],thresholds = thresh)$roc.vol
  
  ##### Extreme gradient boosting ####
  set.seed(100)
  flag<-sample(nrow(train),0.8*nrow(train),replace = F)
  xtrain<-train[flag,]
  xtest<-train[-flag,]
  train_mat<-sparse.model.matrix(data = xtrain,GeoKnowledgeGroup~.-1)
  test_mat<-sparse.model.matrix(data = xtest,GeoKnowledgeGroup~.-1)
  
  train_label<-as.numeric(xtrain$GeoKnowledgeGroup)-1
  test_label<-as.numeric(xtest$GeoKnowledgeGroup)-1
  
  train_dMatrix<-xgb.DMatrix(data = as.matrix(train_mat),label=train_label)
  test_dMatrix<-xgb.DMatrix(data = as.matrix(test_mat),label=test_label)
  
  ## Modeling
  params <- list("objective" = "reg:logistic",
                 "eval_metric" = "auc")
  watchlist <- list(train = train_dMatrix, test = test_dMatrix)
  # eXtreme Gradient Boosting Model
  xgb_model <- xgb.train(params = params,
                         data = train_dMatrix,
                         nrounds = 2000,
                         watchlist = watchlist,
                         eta = 0.02,
                         max.depth = 4,
                         gamma = 0,
                         subsample = 1,
                         colsample_bytree = 1,
                         missing = NA,
                         seed = 222)
  
  tunning<-as.data.frame(xgb_model$evaluation_log)
  rounds<-which(tunning$test_auc==max(tunning$test_auc))
  
  xgb_model <- xgb.train(params = params,
                         data = train_dMatrix,
                         nrounds = rounds[1],
                         watchlist = watchlist,
                         eta = 0.02,
                         max.depth = 4,
                         gamma = 0,
                         subsample = 1,
                         colsample_bytree = 1,
                         missing = NA,
                         seed = 222)
  tunning<-as.data.frame(xgb_model$evaluation_log)
  
  ggplot(data = NULL,aes(x = tunning$iter,y = tunning$train_auc,col='train'))+geom_line()+
    geom_line(aes(y = tunning$test_auc,col='test'))
  
  # Training prediction-
  train_matrix<-sparse.model.matrix(data = train,GeoKnowledgeGroup~.-1)
  train_label<-as.numeric(train$GeoKnowledgeGroup)-1
  train_matrix<-xgb.DMatrix(data = as.matrix(train_matrix),label=train_label)
  
  xgb_prediction.train<-predict(xgb_model, newdata = train_matrix)
  # Prediction on test data-
  # creating test Matrix
  test_matrix<-sparse.model.matrix(data = test,GeoKnowledgeGroup~.-1)
  test_label<-as.numeric(test$GeoKnowledgeGroup)-1
  test_matrix<-xgb.DMatrix(data = as.matrix(test_matrix),label=test_label)
  
  xgb_prediction<-predict(xgb_model, newdata = test_matrix)
  
  # AUC-
  roc.plot(x = test$GeoKnowledgeGroup=="1",pred = xgb_prediction,thresholds = thresh)$roc.vol
  
  # Importance of factors
  imp <- xgb.importance(colnames(train_dMatrix), model = xgb_model)
  xgb.plot.importance(imp)
  
  
  #####################################################
  ### Neural networks ####
  
  ## Cost function
  cost2 <- function(actual, predicted) {
    return(auc(roc(actual,predicted))[1])
  }
  
  avgTrainROC<-NULL
  avgTestROC<-NULL
  for ( j in 1:10 )
  {
    trainRoc<-NULL
    testRoc<-NULL
    for ( i in 1:5)
    {
      set.seed(22*i)
      flags<-sample(nrow(train),0.8*nrow(train),replace = F)
      nnet.train<-train[flags,]
      nnet.test<-train[-flags,]
      model<-nnet(data=nnet.train,GeoKnowledgeGroup~.,size=j,lineout=F,decay=0,maxit=10000)
      train.pred<-predict(model)
      test.pred<-predict(model,nnet.test)
      trainRoc[i]<-cost2(nnet.train$GeoKnowledgeGroup,train.pred)
      testRoc[i]<-cost2(nnet.test$GeoKnowledgeGroup,test.pred)
    }
    avgTrainROC[j]<-mean(trainRoc)
    avgTestROC[j]<-mean(testRoc)
  }
  
  ggplot(data = NULL,aes(x = 1:10,y = avgTrainROC,col='Train'))+geom_line()+
    geom_line(aes(y=avgTestROC,col='Test'))+labs(x="Hidden Layers",y='Average AUC')+
    scale_x_continuous(limits = c(1,10),breaks =seq(1,10,1) )
  
  h<-which(avgTestROC==max(avgTestROC))
  
  avgTrainROC<-NULL
  avgTestROC<-NULL
  d<-NULL
  for ( j in 1:30 )
  {
    trainRoc<-NULL
    testRoc<-NULL
    wt<-j/1000
    d[j]<-wt
    for ( i in 1:5)
    {
      set.seed(22*i)
      flags<-sample(nrow(train),0.8*nrow(train),replace = F)
      nnet.train<-train[flags,]
      nnet.test<-train[-flags,]
      model<-nnet(data=nnet.train,GeoKnowledgeGroup~.,size=h,lineout=F,decay=wt,maxit=10000)
      train.pred<-predict(model)
      test.pred<-predict(model,nnet.test)
      trainRoc[i]<-cost2(nnet.train$GeoKnowledgeGroup,as.numeric(train.pred))
      testRoc[i]<-cost2(nnet.test$GeoKnowledgeGroup,as.numeric(test.pred))
    }
    avgTrainROC[j]<-mean(trainRoc)
    avgTestROC[j]<-mean(testRoc)
  }
  
  ggplot(data = NULL,aes(x = d,y = avgTrainROC,col='Train'))+geom_line()+
    geom_line(aes(y=avgTestROC,col='Test'))+labs(x="Weight Decay",y='Average AUC')+
    scale_x_continuous(limits = c(0,0.03),breaks =seq(0,0.03,0.005) )
  
  dcay<-d[which(avgTestROC==max(avgTestROC))]
  
  nnet.model<-nnet(data=classifierData,GeoKnowledgeGroup~.,size=h,decay=dcay,lineout=F,maxit=10000)
  nnet.prediction<-predict(nnet.model)
  roc.plot(x=train$GeoKnowledgeGroup=="1",pred=nnet.prediction,thresholds = thresh)$roc.vol
  plotnet(nnet.model)
  #####################################################
  ####### Predict test data using our methods #########
  rpart.test.pred<-predict(full.rpart,test,type = 'prob')
  logit.test.pred<-predict(full.log.probit,test,type = 'response')
  lda.test.pred<-predict(model.lda,test)$posterior[,2]
  rf.test.pred<-predict(full.randomForest,test,type = 'prob')[,2]
  nnet.test.pred<-predict(nnet.model,test)
  
  # Plot all test results on one ROC curve
  rocPlot <- roc.plot(x=test$GeoKnowledgeGroup=="1",pred=cbind(logit.test.pred,rpart.test.pred[,2],lda.test.pred,rf.test.pred,xgb_prediction,nnet.test.pred),legend = T,
           leg.text = c("Logistic","DecisionTree","LDA","RandomForest","XGB","NeuralNetwork"),thresholds = thresh)$roc.vol
  
  aucTables <- rbind(aucTables, rocPlot$Area)
}

colnames(aucTables) <- c("Logistic","DecisionTree","LDA","RandomForest","XGB","NeuralNetwork")

meanAUCs <- colMeans(aucTables)


#####################################################
#install pls package (if not already installed)
install.packages("pls")
library(pls)

#use model to make predictions on a test set
train <- as.data.frame(train)
train$GeoKnowledgeGroup <- as.numeric(train$GeoKnowledgeGroup)
y_test <- as.numeric(test$GeoKnowledgeGroup)-1
model <- pcr(GeoKnowledgeGroup~., data=train, scale=TRUE, validation="CV")

validationplot(model, val.type="RMSEP", cex.axis=0.7)
abline(v = 2, col = "blue", lty = 3)

pcr_pred <- predict(model, test, ncomp=2)

geoData.pca1 <- prcomp(train[,1:27], center=TRUE, scale.=TRUE)
nComp <- geoData.pca1$rotation[,1:10]
pcs <- as.data.frame(geoData.pca1$x)

p <- predict(geoData.pca1, newdata=subset(test, type="response"))
pr <- prediction(p, test$GeoKnowledgeGroup)
prf <- performance(pr, measure = "tpr", x.measure = "fpr")
plot(prf)

trainModel <- cbind(train, pcs)
model <- glm(GeoKnowledgeGroup ~ PC1,family=binomial(link='logit'),data=trainModel)


#####################################################

# LOOCV with predicting geo score as a continuous/ordinal variable

contClassifierData <- cbind(classifierData, infoSeekingFullMatrix$GeoKnowledgeScore)
colnames(contClassifierData)[29] <- "GeoKnowledgeScore"

#specify the cross-validation method
ctrl <- trainControl(method = "LOOCV")

#fit a regression model and use LOOCV to evaluate performance
model <- train(GeoKnowledgeGroup ~ T1 + T2 + T3 + T4 + T5 + T6 + T7 + T8 + T9 + T10 +
                 T11 + T12 + T13 + T14 + T15 + T16 + T17 + T19 + T20 +
                 T21 + T22 + T23 + T24 + T25 + T26 + T27 + T29, data = classifierData, method = "binda", trControl = ctrl)

#fit a regression model and use LOOCV to evaluate performance
model <- train(GeoKnowledgeScore ~ T1 + T2 + T3 + T4 + T5 + T6 + T7 + T8 + T9 + T10 +
                 T11 + T12 + T13 + T14 + T15 + T16 + T17 + T19 + T20 +
                 T21 + T22 + T23 + T24 + T25 + T26 + T27 + T29, data = contClassifierData, method = "logreg", trControl = ctrl)

# binda - Binary Discriminant Analysis
# logreg - logic regression (for binary predictors)
# Source: dude just trust me
# http://topepo.github.io/caret/train-models-by-tag.html#Binary_Predictors_Only

print(model)
model$results$RMSE

#####################################################
# PCA Regression

contClassifierData$GeoKnowledgeScore <- as.numeric(contClassifierData$GeoKnowledgeScore)
pcr_model <- pcr(GeoKnowledgeScore~., data = contClassifierData, scale = TRUE, validation = "LOO")

summary(pcr_model)

validationplot(pcr_model)
validationplot(pcr_model, val.type="MSEP")
validationplot(pcr_model, val.type="R2")

pcr_pred <- predict(pcr_model, contClassifierData, ncomp = 11)
mean((pcr_pred - contClassifierData$GeoKnowledgeScore)^2)
# This is the average deviation between the predicted value and the observed value



#####################################################
# Training on each question and testing on others

classifierDataGRE <- classifierData[grep("GRE", rownames(classifierData)), ]
classifierDataMON <- classifierData[grep("MON", rownames(classifierData)), ]
classifierDataKOR <- classifierData[grep("KOR", rownames(classifierData)), ]
classifierDataBOT <- classifierData[grep("BOT", rownames(classifierData)), ]
classifierDataCOL <- classifierData[grep("COL", rownames(classifierData)), ]
classifierDataSWI <- classifierData[grep("SWI", rownames(classifierData)), ]


model.ldaGRE<-lda(data=classifierDataGRE,GeoKnowledgeGroup~.)
model.ldaMON<-lda(data=classifierDataMON,GeoKnowledgeGroup~.)
model.ldaKOR<-lda(data=classifierDataKOR,GeoKnowledgeGroup~.)
model.ldaBOT<-lda(data=classifierDataBOT,GeoKnowledgeGroup~.)
model.ldaCOL<-lda(data=classifierDataCOL,GeoKnowledgeGroup~.)
model.ldaSWI<-lda(data=classifierDataSWI,GeoKnowledgeGroup~.)

models <- list(model.ldaGRE, model.ldaMON, model.ldaKOR, model.ldaBOT, model.ldaCOL, model.ldaSWI)

questionClassificationROCTable <- data.frame(matrix(nrow = 6, ncol = 6))
rownames(questionClassificationROCTable) <- c("GRE", "MON", "KOR", "BOT", "COL", "SWI")
colnames(questionClassificationROCTable) <- c("GRE", "MON", "KOR", "BOT", "COL", "SWI")
for (x in 1:6)
{
  for (y in 1:6)
  {
    if (x == y)
    {
      questionClassificationROCTable[x,y] <- 0
    }
    else
    {
      currentTrainingModel <- models[[x]]
      q <- colnames(questionClassificationROCTable)[y]
      currentTestData <- classifierData[grep(q, rownames(classifierData)), ]
      testpred <-predict(currentTrainingModel,currentTestData)$posterior[,2]
      rocCurve <- roc.plot(x=currentTestData$GeoKnowledgeGroup=="1",pred=testpred,thresholds = thresh)$roc.vol
      questionClassificationROCTable[x,y] <- rocCurve$Area
    }
  }
}

decTreeFeatsGRE <-rpart(data = classifierDataGRE,GeoKnowledgeGroup~.,method = 'class',parms=list(prior = c(.65,.35), split="information"))$variable.importance[1:5]
decTreeFeatsMON <-rpart(data = classifierDataMON,GeoKnowledgeGroup~.,method = 'class',parms=list(prior = c(.65,.35), split="information"))$variable.importance[1:5]
decTreeFeatsKOR <-rpart(data = classifierDataKOR,GeoKnowledgeGroup~.,method = 'class',parms=list(prior = c(.65,.35), split="information"))$variable.importance[1:5]
decTreeFeatsBOT <-rpart(data = classifierDataBOT,GeoKnowledgeGroup~.,method = 'class',parms=list(prior = c(.65,.35), split="information"))$variable.importance[1:5]
decTreeFeatsCOL <-rpart(data = classifierDataCOL,GeoKnowledgeGroup~.,method = 'class',parms=list(prior = c(.65,.35), split="information"))$variable.importance[1:5]
decTreeFeatsSWI <-rpart(data = classifierDataSWI,GeoKnowledgeGroup~.,method = 'class',parms=list(prior = c(.65,.35), split="information"))$variable.importance[1:5]


####################################
# Training and testing by case ###
# Using neural networks #

## Cost function
cost2 <- function(actual, predicted) {
  return(auc(roc(actual,predicted))[1])
}

classifierDataGRE <- classifierData[grep("GRE", rownames(classifierData)), ]
classifierDataMON <- classifierData[grep("MON", rownames(classifierData)), ]
classifierDataKOR <- classifierData[grep("KOR", rownames(classifierData)), ]
classifierDataBOT <- classifierData[grep("BOT", rownames(classifierData)), ]
classifierDataCOL <- classifierData[grep("COL", rownames(classifierData)), ]
classifierDataSWI <- classifierData[grep("SWI", rownames(classifierData)), ]

#Order by difficulty
classifierDataDfs <- c()
classifierDataDfs[[1]] <- classifierDataKOR
classifierDataDfs[[2]] <- classifierDataMON
classifierDataDfs[[3]] <- classifierDataCOL
classifierDataDfs[[4]] <- classifierDataSWI
classifierDataDfs[[5]] <- classifierDataGRE
classifierDataDfs[[6]] <- classifierDataBOT


hiddenLayers <- c()
dcays <- c()
models <- list()

for (dfn in 1:6)
{
  avgTrainROC<-NULL
  avgTestROC<-NULL
  dataTrain <- classifierDataDfs[[dfn]]
  for ( j in 1:10 )
  {
    trainRoc<-NULL
    testRoc<-NULL
    for ( i in 1:50)
    {
      set.seed(22*i)
      flags<-sample(nrow(dataTrain),0.8*nrow(dataTrain),replace = F)
      nnet.train<-dataTrain[flags,]
      nnet.test<-dataTrain[-flags,]
      model<-nnet(data=nnet.train,GeoKnowledgeGroup~.,size=j,lineout=F,decay=0,maxit=10000)
      train.pred<-predict(model)
      test.pred<-predict(model,nnet.test)
      trainRoc[i]<-cost2(nnet.train$GeoKnowledgeGroup,train.pred)
      testRoc[i]<-cost2(nnet.test$GeoKnowledgeGroup,test.pred)
    }
    avgTrainROC[j]<-mean(trainRoc)
    avgTestROC[j]<-mean(testRoc)
  }
  
  h<-which(avgTestROC==max(avgTestROC))
  hiddenLayers[dfn] <- h
  
  avgTrainROC<-NULL
  avgTestROC<-NULL
  d<-NULL
  for ( j in 1:30 )
  {
    trainRoc<-NULL
    testRoc<-NULL
    wt<-j/1000
    d[j]<-wt
    for ( i in 1:50)
    {
      set.seed(22*i)
      flags<-sample(nrow(dataTrain),0.8*nrow(dataTrain),replace = F)
      nnet.train<-dataTrain[flags,]
      nnet.test<-dataTrain[-flags,]
      model<-nnet(data=nnet.train,GeoKnowledgeGroup~.,size=h,lineout=F,decay=wt,maxit=10000)
      train.pred<-predict(model)
      test.pred<-predict(model,nnet.test)
      trainRoc[i]<-cost2(nnet.train$GeoKnowledgeGroup,as.numeric(train.pred))
      testRoc[i]<-cost2(nnet.test$GeoKnowledgeGroup,as.numeric(test.pred))
    }
    avgTrainROC[j]<-mean(trainRoc)
    avgTestROC[j]<-mean(testRoc)
  }
  
  dcay<-d[which(avgTestROC==max(avgTestROC))]
  dcays[dfn] <- dcay
  
  nnet.model<-nnet(data=dataTrain,GeoKnowledgeGroup~.,size=hiddenLayers[dfn],decay=dcays[dfn],lineout=F,maxit=10000)
  models[[dfn]] <- nnet.model
}

questionClassificationROCTableNN <- data.frame(matrix(nrow = 6, ncol = 6))
rownames(questionClassificationROCTableNN) <- c("KOR","MON","COL","SWI", "GRE", "BOT")
colnames(questionClassificationROCTableNN) <- c("KOR","MON","COL","SWI", "GRE", "BOT")
for (x in 1:6)
{
  for (y in 1:6)
  {
    if (x == y)
    {
      questionClassificationROCTableNN[x,y] <- 0
    }
    else
    {
      currentTrainingModel <- models[[x]]
      q <- colnames(questionClassificationROCTableNN)[y]
      currentTestData <- classifierData[grep(q, rownames(classifierData)), ]
      testpred <-predict(currentTrainingModel,currentTestData)
      rocCurve <- roc.plot(x=currentTestData$GeoKnowledgeGroup=="1",pred=testpred,thresholds = thresh)$roc.vol
      questionClassificationROCTableNN[x,y] <- rocCurve$Area
    }
  }
}
# Train on rows, test on columns

########################
###### Fit the regression model of the different questions/case

#specify the cross-validation method
ctrl <- trainControl(method = "LOOCV")

# binda - Binary Discriminant Analysis
# logreg - logic regression (for binary predictors)
# Source: dude just trust me
# http://topepo.github.io/caret/train-models-by-tag.html#Binary_Predictors_Only

print(model)

rmseVals <- data.frame(matrix(nrow=6,ncol=2))
rownames(rmseVals) <- c("KOR","MON","COL","SWI", "GRE", "BOT")
colnames(rmseVals) <- c("RMSE", "MAE")
for (x in 1:6)
{
    q <- rownames(rmseVals)[x]
    currentData <- contClassifierData[grep(q, rownames(contClassifierData)), ]
    #fit a regression model and use LOOCV to evaluate performance
    model <- train(GeoKnowledgeScore ~ T1 + T2 + T3 + T4 + T5 + T6 + T7 + T8 + T9 + T10 +
                     T11 + T12 + T13 + T14 + T15 + T16 + T17 + T19 + T20 +
                     T21 + T22 + T23 + T24 + T25 + T26 + T27 + T29, data = currentData, method = "lm", trControl = ctrl)
    rmseVals[x,1] <- model$results$RMSE
    rmseVals[x,2] <- model$results$MAE
}



###################################
# Looking at information seeking collapsed across trials


classifierDataColl <- infoSeekingCollMatrix[,c(1:17,19:27,29:33)]
colnames(classifierDataColl) <- c("T1","T2",  "T3",  "T4",  "T5",  "T6",  "T7",  "T8",  "T9", "T10", "T11", "T12", "T13", "T14", "T15", "T16", "T17", "T19", "T20", "T21", "T22", "T23", "T24", "T25", "T26", "T27", "T29", "ID", "ParticipantAccuracy", "LikelihoodCorrect", "GeoScore")

#specify the cross-validation method
ctrl <- trainControl(method = "LOOCV")

#fit a regression model and use LOOCV to evaluate performance
model <- train(GeoScore ~ T1 + T2 + T3 + T4 + T5 + T6 + T7 + T8 + T9 + T10 +
                 T11 + T12 + T13 + T14 + T15 + T16 + T17 + T19 + T20 +
                 T21 + T22 + T23 + T24 + T25 + T26 + T27 + T29, data = classifierDataColl, method = "lm", trControl = ctrl)


print(model)
model$results$RMSE

####

pcr_model <- pcr(GeoScore~ T1 + T2 + T3 + T4 + T5 + T6 + T7 + T8 + T9 + T10 +
                   T11 + T12 + T13 + T14 + T15 + T16 + T17 + T19 + T20 +
                   T21 + T22 + T23 + T24 + T25 + T26 + T27 + T29, data = classifierDataColl, scale = TRUE, validation = "LOO")

summary(pcr_model)

validationplot(pcr_model)

pcr_pred <- predict(pcr_model, classifierDataColl, ncomp = 2)
mean((pcr_pred - classifierDataColl$GeoScore)^2)
